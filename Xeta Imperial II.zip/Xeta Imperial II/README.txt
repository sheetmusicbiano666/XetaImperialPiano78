-- IMPORTANT --
If you use this soundfont, you MUST credit yun and pon.
"Xeta Imperial II was made by Pon MIDIs and yuni."

-- from pon --

Thanks for downloading Xeta Imperial II!
Hope you enjoy this soundfont collaboration I've had with yun!! They've been a great help with telling me how I should tweak the samples.
They are also the ones who've made the fantasy presets, with a bit of tweaks/optimizations by me.
All of the soundfont optimizations were done by me.
Enjoy the soundfont!!